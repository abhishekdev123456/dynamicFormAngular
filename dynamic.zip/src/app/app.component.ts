import { Component, OnInit } from '@angular/core';
import {  dynamicJSON } from './constants/multi-step-form';
import { Model }  from './model';
import { ConfirmationService } from 'primeng/api';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit  {
  title = 'demo';
  display: boolean = false;
  result:any = [];
  formContent: any;
  formData: any;
  activeStepIndex: number;
  constructor(private confirmationService: ConfirmationService) {}
  ngOnInit(): void {
    dynamicJSON.map((item,i)=>{
      this.result
          .push({ 'label': item.key,
                  'data':{[`${item.key}`]: { 'type': item.type, 'options':item.options?item.options:[], 'validations':  { required: item.required},
                  'errors': {},
                  'placeholder': item.label }
                  }});

        if(dynamicJSON.length-1 == i)
        {
        this.result.push({label: 'Review & Submit', data: {}});
        }
    });
    this.formContent = this.result;
    this.formData = {};
  }
    
  onFormSubmit(formData: any): void {
    this.formData = formData;
    
    // post form data here
    alert(JSON.stringify(this.formData));
  }

  showDialog() {
    this.display = true;
  }

  close(event){
    let p = localStorage.getItem('progress');
    this.confirmationService.confirm({
      message: `Don't stop now. You are ${p}% done
      with your request.`,
      accept: () => {
        this.display = false;
      }
  });
  }
}
