const dynamicJSON = [
  {
      "key": "task_date",
      "label": "When do you want ?",
      "type": "calender",
      "value": "",
      "required": true,
      "order": 1
  },
  {
      "key": "bathrooms",
      "label": "How many bathrooms ?",
      "type": "radio",
      "options":[{
        "value":1,
        "label":"1 bathrooms"
       },
       {
         "value":2,
         "label":"2 bathrooms"
        },
        {
          "value":3,
          "label":"3 bathrooms"
        },
        {
          "value":4,
          "label":"4 bathrooms"
        }],
      "required": true,
      "order": 2
  },
  {
    "key": "cleaning",
    "label": "What kind of cleaning do you need?",
    "type": "radio",
    "options":[{
      "value":1,
      "label":"Deep cleaning"
     },
     {
       "value":2,
       "label":"Standard cleaning"
      },
      {
        "value":3,
        "label":"Move out cleaning"
      }
    ],
    "required": true,
    "order": 3
  },
  {
    "key": "extracleaning",
    "label": "Do you need any extras?",
    "type": "checkbox",
    "options":[{
      "value":"Window cleaning (Interior)",
      "label":"Window cleaning (Interior)"
    },
    {
      "value":"Fridge cleaning",
      "label":"Fridge cleaning"
      },
      {
        "value":"Ovan cleaning",
        "label":"Ovan cleaning"
      }
    ],
    "required": true,
    "order": 4
  }
];


export { dynamicJSON }