import { Injectable } from '@angular/core';
import "rxjs/add/observable/of";
import { Observable } from 'rxjs/Observable';
import { map } from "rxjs/operators";

@Injectable()
export class QuestionService {

    subscription: any = null;
    constructor() {}
    
    onLoginError(): Observable<any> {
        return Observable.of({});
    }
}