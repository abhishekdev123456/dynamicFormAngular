export class Model {
    label: any;
    data: any;
  }