import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'trimString'
})
export class trimStringPipe implements PipeTransform {
  transform(val: string): string {
    const result = val.replace(/ /g, "");
    return result;
  }
}
